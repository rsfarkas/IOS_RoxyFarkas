//
//  gameOver.swift
//  SheepCounter
//
//  Created by Roxanne Farkas on 2/17/17.
//  Copyright © 2017 newschool. All rights reserved.
//


import SpriteKit
import GameplayKit

import UIKit

class gameOver: SKScene {
//game over message should appear here
//when user taps , reroute back to menuScene
    
}
