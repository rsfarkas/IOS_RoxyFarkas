//
//  GameScene.swift
//  SheepCounter
//
//  Created by Roxanne Farkas on 2/11/17.

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    // "global to object"
    var score = 0
    let winningScore = 100;
    
    //properties, define must "?"
    var player: SKSpriteNode?  //optional, "nil"
    var enemy: SKSpriteNode? //
    var laser:SKShapeNode?
    var label : SKLabelNode?
    var label2: SKLabelNode?
    
    var zShots: SKSpriteNode?
  
    override func didMove(to view: SKView) {
        self.physicsWorld.contactDelegate = self
        
        // as is "casting"
        player = self.childNode(withName: "player") as! SKSpriteNode?
        enemy = self.childNode(withName: "sheep") as! SKSpriteNode?
        label = self.childNode(withName: "myLabel") as! SKLabelNode?
        label2 = self.childNode(withName: "label2") as! SKLabelNode?
        laser = self.childNode(withName: "laser") as? SKShapeNode
        
        zShots = self.childNode(withName: "zShots") as? SKSpriteNode
        
        updateLabel()
    }
    
    
    
    func makeZees(){
        zShots = SKSpriteNode()
        zShots?.size = CGSize(width: 32, height: 32)
        zShots?.texture = SKTexture(image: #imageLiteral(resourceName: "zShot"))
        
        zShots?.position = (player?.position)!
        
        zShots?.physicsBody = SKPhysicsBody(circleOfRadius: 25)
        zShots?.physicsBody?.affectedByGravity = false
        zShots?.physicsBody?.velocity = CGVector(dx: 0, dy: 350)
        zShots?.physicsBody?.contactTestBitMask = 2
        
        self.addChild(zShots!)
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("touches began")
        
        makeZees()
        
        for  t in touches {
            print("t= \(t.location(in: self))")
            
            player?.position.x = t.location(in: self).x
            
        }
        
    }
    
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("touches moved")
        
        
        for  t in touches {

            // move player's X position to that point.
            player?.position.x = t.location(in: self).x
            
            // Shot!
            makeZees()
            
        }
    }
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("touches ended")
        
        for  t in touches {
            
            // move player's X position to that point.
            player?.position.x = t.location(in: self).x
            
            // Shot!
            makeZees()
            
        }
        
    }
    
    
    func updateLabel(){
        label?.text = "Float Score: \(score) "
        
        if score >= winningScore{
            enemy?.removeFromParent()
            label?.text = "You defeated the sheep!"
            label2?.text = "Time for sleep!"
            
        }
        
    }
    
    func didBegin(_ contact: SKPhysicsContact) {

        if (contact.bodyA.contactTestBitMask == 1){
            score = score + 1
            updateLabel()
            
        }
        
        if (contact.bodyB.contactTestBitMask == 1){
            score = score + 1
            updateLabel()
        }
        
        if ((contact.bodyA.contactTestBitMask == 2) || (contact.bodyA.contactTestBitMask == 3)){
            contact.bodyA.node?.removeFromParent()
            
        }
        
    }
    
}
